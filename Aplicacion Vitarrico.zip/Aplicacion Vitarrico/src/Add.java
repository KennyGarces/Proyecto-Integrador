import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.File;

import java.util.Scanner;


public class Add {
    public JPanel addMain;
    private JButton btnexit;
    private JTextField textProduct;
    private JTextField textPrice;
    private JButton ADDButton;
    private JTable tableProduct;
    private JTextField textGrams;
    private JButton OPENLISTButton;


    public void limpiar() {
        textProduct.setText("");
        textGrams.setText("");
        textPrice.setText("");
    }

    public Add() {

        String[] cols = {"Name Product","Grams", "Unit Price"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        tableProduct.setModel(model);

        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Object[] data = {textProduct.getText(),textGrams.getText(), textPrice.getText()};
                    model.addRow(data);
                } catch (Exception ex) {
                    System.out.println("Error");
                }
                try {
                    FileWriter save = new FileWriter("C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\ListProductos.txt");
                    for (int i = 0; i < tableProduct.getRowCount(); i++) {
                        save.write(model.getValueAt(i, 0).toString() + ("\n"));
                        save.write(model.getValueAt(i, 1).toString() + ("\n"));
                        save.write(model.getValueAt(i, 2).toString() + ("\n"));
                    }
                    save.close();
                    JOptionPane.showMessageDialog(null, "Successfully saved");
                } catch (Exception ex) {
                    System.out.println("Error");
                }
                limpiar();
            }
        });

        btnexit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame1 = new JFrame("Login Vitarrico");
                frame1.setContentPane(new MENU().MenuPPal);
                frame1.setSize(1000, 500);
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setVisible(true);
            }
        });


        OPENLISTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Producto, Gramos, Precio;
                String archivo = "C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\ListProductos.txt";
                Scanner linea = null;
                File abrirTxt = new File(archivo);
                try {
                    linea = new Scanner(abrirTxt);
                    while (linea.hasNextLine()) {
                        Producto = linea.nextLine();
                        Gramos = linea.nextLine();
                        Precio = linea.nextLine();
                        model.addRow(new Object[]{Producto, Gramos, Precio});
                    }
                } catch (Exception ez) {
                    JOptionPane.showMessageDialog(null, "Error");
                }

            }
        });





    }
}
