import java.util.Vector;

public class Usuario {
    private String usuario;
    private String password;
    private String rpassword;

    public String getUsuario() {
        return usuario;
    }

    public void setusuario(String usuario) {
        this.usuario = usuario;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String password ) {
        this.password = password;
    }

    public String getrpassword() {
        return rpassword;
    }

    public void setrpassword(String rpassword) {
        this.rpassword = rpassword;
    }
    public static int verificarUsuario(String usuario){
        Vector lista = mostrar();
        Usuario obj;
        for(int i=0;i<lista.size();i++){
            obj = (Usuario) lista.elementAt(i);
            if(obj.getUsuario().equalsIgnoreCase(usuario)){
                return i;
            }
        }
        return -1;
    }
    public static int verificarLogin(String usuario,String contraseña){
        Vector lista = mostrar();
        Usuario obj;
        for(int i = 0;i<lista.size();i++){
            obj = (Usuario) lista.elementAt(i);
            if(obj.getUsuario().equalsIgnoreCase(usuario)&& obj.getrpassword().equalsIgnoreCase(contraseña)){
                return i;
            }
        }
        return -1;
    }

    public static Vector mostrar(){
        return ListUser.mostrar();
    }
}
