import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class LoginVitarrico {

    public JPanel pnlMain;
    private JPanel panel2;
    private JPanel panel3;
    private JLabel lblLogo;
    private JTextField textUser;
    private JLabel lblLogin;
    private JLabel lblPassword;
    private JPasswordField pswPassword;
    private JLabel lblUsername;
    private JLabel lblForget;
    private JButton signUpButton;
    private JButton signInButton;
    private JButton buttonBUY;


    public LoginVitarrico(){


        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame2 = new JFrame(" Main Menú Vitarrico");
                frame2.setContentPane(new Register().pnlRegister);
                frame2.setSize(1000,500);
                frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame2.setVisible(true);

            }
        });

        buttonBUY.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame2 = new JFrame(" Main Menú Vitarrico");
                frame2.setContentPane(new BuyC().pnlBuyC);
                frame2.setSize(1000,500);
                frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame2.setVisible(true);

            }
        });
        signInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = textUser.getText();
                String password = pswPassword.getText();
                if(usuario.isEmpty() || password.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Error: Make sure you enter the data correctly.");

                }else{
                    if(usuario.equals("kamila_pineda") && password.equals("123456")){
                        JFrame frame3 = new JFrame(" Menú Principal Vitarrico");
                        frame3.setContentPane(new PagePrincipal().jpPprimer);
                        frame3.setSize(1000,500);
                        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame3.setVisible(true);
                    }
                    if(usuario.equals("kenny_garces") && password.equals("123456")){
                        JFrame frame3 = new JFrame(" Menú Principal Vitarrico");
                        frame3.setContentPane(new PagePrincipal().jpPprimer);
                        frame3.setSize(1000,500);
                        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame3.setVisible(true);
                    }
                    if(!usuario.equals("kenny_garces") && !password.equals("123456") && !usuario.equals("kamila_pineda") && !password.equals("123456")){
                        int x = Usuario.verificarLogin(usuario,password);
                        if(x == -1){
                            JOptionPane.showMessageDialog(null,"Error: Make sure you enter the data correctly.");
                        }else{

                            JFrame frame3 = new JFrame(" Menú Principal Vitarrico");
                            frame3.setContentPane(new PagePrincipal().jpPprimer);
                            frame3.setSize(1000,500);
                            frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            frame3.setVisible(true);

                        }
                    }

                }
            }
        });


    }
}
