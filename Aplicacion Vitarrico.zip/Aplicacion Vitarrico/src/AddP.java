import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class AddP {
    public JPanel jplAddP;
    private JTextField textName;
    private JTextField textCode;
    private JTable tableSupplier;
    private JButton OPENButton;
    private JButton ADDButton;
    private JButton btnExit;

    public void limpiar() {
        textName.setText("");
        textCode.setText("");}





    public AddP(){

        String[] cols = {"NAME","CODE"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        tableSupplier.setModel(model);

        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Object[] data = {textName.getText(),textCode.getText()};
                    model.addRow(data);
                } catch (Exception ex) {
                    System.out.println("Error");
                }

                try {
                    FileWriter save = new FileWriter("C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\ListProveedores.txt");
                    for (int i = 0; i < tableSupplier.getRowCount(); i++) {
                        save.write(model.getValueAt(i, 0).toString() + ("\n"));
                        save.write(model.getValueAt(i, 1).toString() + ("\n"));

                    }
                    save.close();
                    JOptionPane.showMessageDialog(null, "Successfully saved");
                } catch (Exception ex) {
                    System.out.println("Error");
                }
                limpiar();
            }

        });

       OPENButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String Nombre, Codigo;
                String archivo = "C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\ListProveedores.txt";
                Scanner linea = null;
                File abrirTxt = new File(archivo);
                try {
                    linea = new Scanner(abrirTxt);
                    while (linea.hasNextLine()) {
                        Nombre = linea.nextLine();
                        Codigo = linea.nextLine();

                        model.addRow(new Object[]{Nombre, Codigo });
                    }
                } catch (Exception ez) {
                    JOptionPane.showMessageDialog(null, "Error");
                }

            }
        });

        btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame1 = new JFrame("Login Vitarrico");
                frame1.setContentPane(new MenuPPal().pnlMenu);
                frame1.setSize(1000, 500);
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setVisible(true);
            }
        });
    }
}
