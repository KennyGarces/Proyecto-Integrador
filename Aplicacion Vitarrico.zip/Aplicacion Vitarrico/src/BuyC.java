import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BuyC {
    public JPanel pnlBuyC;
    private JButton btnExit;
    private JTextField txtName;
    private JTextField txtUnits;
    private JTextField txtPrice;
    private JTextField txtSubTotal;
    private JButton BUYButton;
    private JTextField txtTax;
    private JTextField txtTotal;
    private JButton btnR;
    private JTable table1;
    private JButton OPENButton;
    private JTable table2;

    private File file;
    public Object total() {
        double valorU = Double.parseDouble(txtPrice.getText());
        double cantidad = Double.parseDouble(txtUnits.getText());
        double total = (valorU * cantidad);
        return total;

    }

    private void compraTotal(){
        float suma = 0;
        for(int i= 0;i < table2.getRowCount();i++){
            float renglon;
            renglon = Float.parseFloat(table2.getValueAt(i,3).toString());
            suma += renglon;
        }
        txtSubTotal.setText(String.valueOf(suma));
        txtTax.setText(String.valueOf(suma*0.19));
        txtTotal.setText(String.valueOf(suma*1.19));
    }
    public void limpiar(){
        txtName.setText("");
        txtPrice.setText("");
        txtUnits.setText("");}
    private List<BUY> Buy = new ArrayList<BUY>();

    private void guardarTxt(){
        try{
            FileWriter fw = new FileWriter("C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\Factura2.txt",true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print("\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n");
            pw.print("Product: "+txtName.getText()+"\n");
            pw.print("Units: " + txtUnits.getText()+"-");
            pw.print("Price: " + txtPrice.getText()+"\n");

            pw.print("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n");
            pw.print("Purchase value: " + txtSubTotal.getText()+"\n");
            pw.print("Tax: "+txtTax.getText()+"\n");
            pw.print("TOTAL TO PAY: " + txtTotal.getText()+"\n");
            pw.print("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n");
            pw.print("\n");
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public BuyC(){
        String[] cols1 = {"Product", "Price", "Units", "Total"};
        DefaultTableModel model1 = new DefaultTableModel(cols1, 0);
        table2.setModel(model1);

        btnR.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Object[] data = {txtName.getText(), txtPrice.getText(), txtUnits.getText(), total()};
                    model1.addRow(data);}catch (Exception ex){
                    System.out.println("Error");
                }
                compraTotal();
                guardarTxt();
                limpiar();
            }
        });
        BUYButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\Factura2.txt";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {

                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

            }
        });

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                JTable table = (JTable) e.getSource();
                Point point = e.getPoint();
                int row = table.rowAtPoint(point);
                if(e.getClickCount()== 1){
                    txtName.setText(table1.getValueAt(table1.getSelectedRow(),0).toString());
                    txtPrice.setText(table1.getValueAt(table1.getSelectedRow(),2).toString());

                }
            }
        });
        String[] cols = {"Name Product","Grams", "Unit Price"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        table1.setModel(model);

        OPENButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Producto, Gramos, Precio;
                String archivo = "C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\ListProductos.txt";
                Scanner linea = null;
                File abrirTxt = new File(archivo);
                try {
                    linea = new Scanner(abrirTxt);
                    while (linea.hasNextLine()) {
                        Producto = linea.nextLine();
                        Gramos = linea.nextLine();
                        Precio = linea.nextLine();
                        model.addRow(new Object[]{Producto, Gramos, Precio,});
                    }
                } catch (Exception ez) {
                    JOptionPane.showMessageDialog(null, "Error");
                }

            }
        });

        btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame1 = new JFrame("Login Vitarrico");
                frame1.setContentPane(new LoginVitarrico().pnlMain);
                frame1.setSize(1000, 500);
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setVisible(true);
            }
        });
    }
}
