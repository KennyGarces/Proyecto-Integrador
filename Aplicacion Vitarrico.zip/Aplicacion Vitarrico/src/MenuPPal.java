import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPPal {
    public JPanel pnlMenu;
    private JButton btnAdd;
    private JButton btnDelete;
    private JButton btnBuy;
    private JButton btnView;
    private JLabel lblIcon;
    private JButton btnExit;


    public MenuPPal(){

       btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame1 = new JFrame("Main");
                frame1.setContentPane(new  PagePrincipal().jpPprimer);
                frame1.setSize(1000, 500);
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setVisible(true);

            }
        });

       btnAdd.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {

               JFrame frame1 = new JFrame("ADD");
               frame1.setContentPane(new AddP().jplAddP);
               frame1.setSize(1000, 500);
               frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame1.setVisible(true);

           }
       });

       btnView.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {

               JFrame frame1 = new JFrame("VIEW");
               frame1.setContentPane(new ListP().pnlListP);
               frame1.setSize(1000, 500);
               frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame1.setVisible(true);

           }
       });


        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame1 = new JFrame("BUY");
                frame1.setContentPane(new DeleteP().pnlDeleteP);
                frame1.setSize(1000, 500);
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setVisible(true);

            }
        });
    }

}

