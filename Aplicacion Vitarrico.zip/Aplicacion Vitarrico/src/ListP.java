import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Scanner;

public class ListP {
    private JButton btnExit;
    private JTextField textList;
    private JButton SEARCHButton;
    private JButton OPENButton;
    private JTable table1;
    public JPanel pnlListP;

    private TableRowSorter trsFilter;
    String Filter;

    private File file;

    public void filter(){
        Filter = textList.getText();
        trsFilter.setRowFilter(RowFilter.regexFilter(textList.getText(),0));}

    public ListP(){

        SEARCHButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textList.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        String cadena = textList.getText();
                        textList.setText(cadena);
                        filter();
                    }
                });
            }
        });
        String[] cols = {"NAME","CODE"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        table1.setModel(model);

        OPENButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Nombre, Codigo;
                String archivo = "C:\\Users\\Usuario\\Documents\\Trabajos III\\PI1\\Aplicacion Vitarrico\\ListProveedores.txt";
                Scanner linea = null;
                File abrirTxt = new File(archivo);
                try {
                    linea = new Scanner(abrirTxt);
                    while (linea.hasNextLine()) {
                        Nombre = linea.nextLine();
                        Codigo = linea.nextLine();

                        model.addRow(new Object[]{Nombre, Codigo });
                    }
                } catch (Exception ez) {
                    JOptionPane.showMessageDialog(null, "Error");
                }
            }
        });

        textList.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                trsFilter = new TableRowSorter(table1.getModel());
                table1.setRowSorter(trsFilter);
            }
        });

        btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame1 = new JFrame("Login Vitarrico");
                frame1.setContentPane(new MenuPPal().pnlMenu);
                frame1.setSize(1000, 500);
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setVisible(true);
            }
        });
    }
}
